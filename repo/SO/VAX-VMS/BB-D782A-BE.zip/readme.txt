This tape image is not read from an original tape.
It was reconstructed from a disk containing early VAX/VMS source and binaries.
The dates indicate this is earlier than VAX/VMS V1.5.
